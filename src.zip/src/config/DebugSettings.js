export default {
	yellowBox: __DEV__
};
