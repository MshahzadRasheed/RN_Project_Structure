export const getUser = state => state.user.data;
