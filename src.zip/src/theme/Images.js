// images
const logo = require('../assets/images/squareLogo.png');
const back_btn = require('../assets/icons/back/back.png');

// icons
export default {
  logo,
  back_btn,
};
